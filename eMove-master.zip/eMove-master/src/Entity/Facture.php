<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\FactureRepository")
 */
class Facture
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity="App\Entity\Location", cascade={"persist", "remove"})
     */
    private $location;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\StatusFacture", inversedBy="factures")
     */
    private $statusFacture;

    /**
     * @ORM\Column(type="float")
     */
    private $price;

    public function getId()
    {
        return $this->id;
    }

    public function getLocation(): ?Location
    {
        return $this->location;
    }

    public function setLocation(?Location $location): self
    {
        $this->location = $location;

        return $this;
    }

    public function getStatusFacture(): ?StatusFacture
    {
        return $this->statusFacture;
    }

    public function setStatusFacture(?StatusFacture $statusFacture): self
    {
        $this->statusFacture = $statusFacture;

        return $this;
    }

    public function getPrice(): ?float
    {
        return $this->price;
    }

    public function setPrice(float $price): self
    {
        $this->price = $price;

        return $this;
    }
}
